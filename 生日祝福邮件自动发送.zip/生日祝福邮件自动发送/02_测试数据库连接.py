"""
 @author : 唐仕恒
 @filename : 02_测试数据库连接.py
 @createtime :2020/6/26 20:02
 @IDE : PyCharm
"""
from SqlServer import SqlServer

host = 'localhost'
user = 'root'
password = 'root'
database = 'BIRTHDAY'
connect = SqlServer(host, user, password, database)

sql = 'select top 10 name, email from tb_birthday'
result = connect.get_all(sql)

print(type(result), len(result))
if result:
    for row in result:
        print(row, type(row))


