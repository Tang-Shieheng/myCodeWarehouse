"""
 @author : 唐仕恒
 @filename : 03_连接邮箱服务器.py
 @createtime :2020/6/26 20:39
 @IDE : PyCharm
"""
import smtplib
from email.mime.multipart import MIMEMultipart      # 创建邮件对象（被发送的东西）
from email.header import Header     # 创建邮件主题（邮件主题）
from email.mime.text import MIMEText    # 创建邮件内容（邮件正文）

# 1.连接邮件服务器
# 1）smtplib.SMTP_SSL(邮箱服务器. 端口号)
con = smtplib.SMTP_SSL('smtp.163.com', 465)
# 2)登录邮箱
# con.login(邮箱地址, 授权码）
''' 
注：con.login()正常情况下只需填写授权码即可，但此处若我的授权码写成明文的话就可以被别人随便登录了。
故我提前在项目文件下创建了一个文件夹files、再创建一个password文件用来保存我的授权码
使用时只需要读文件即可得到授权码。可以不用模仿
'''
con.login('17073858552@163.com', open('files/password', encoding='utf-8').read())

# 2.准备数据
# 1）创建邮件对象
msg = MIMEMultipart()
# 2）设置邮件主题
# Header(标题， 编码方式)
subject = Header('生日祝福', 'utf-8').encode()
msg['Subject'] = subject
# 设置邮件发送人： 邮箱地址<邮箱地址>
msg['From'] = '17073858552@163.com <17073858552@163.com>'
# 设置邮件收件人
# '收件人1；收件人2；...'
msg['To'] = '415331174@qq.com'
# 3)设置邮件正文
# 普通文本：MIMEText(文本内容，文本类型，编码方式)
# 文本类型 -plain(普通文字)、html(超链接)、base64(二进制文件，即附件)
text = MIMEText('生日快乐！', 'plain', 'utf-8')
msg.attach(text)

# 3.发送邮件
# 连接对象.sendmail(发件人， 收件人， 字符串类型的邮件对象)
con.sendmail('17073858552@163.com', '415331174@qq.com', msg.as_string())
con.quit()
