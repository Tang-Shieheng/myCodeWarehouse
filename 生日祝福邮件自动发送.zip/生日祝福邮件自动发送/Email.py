"""
 @author : 唐仕恒
 @filename : Email.py
 @createtime :2020/6/26 21:30
 @IDE : PyCharm
"""
import smtplib
from email.mime.multipart import MIMEMultipart
from email.header import Header
from email.mime.text import MIMEText

class Email():
    def __init__(self, MailServer, port, email, password):
        self.MailServer = MailServer
        self.port = port
        self.email = email
        self.password = password


    def connect(self):
        self.con = smtplib.SMTP_SSL(self.MailServer, self.port)
        self.con.login(self.email, self.password)


    def sendmail(self, Sender, To, Subject, Text):
        self.connect()
        msg = MIMEMultipart()
        # 设置邮件主题
        subject = Header(Subject, 'utf-8').encode()
        msg['Subject'] = subject
        # 设置邮件发送人： 邮箱地址<邮箱地址>
        From = self.Senter_to_from(Sender)
        msg['From'] = From
        # 设置邮件收件人
        msg['To'] = To
        # 设置邮件正文
        text = MIMEText(Text, 'plain', 'utf-8')
        msg.attach(text)

        # 发送邮件
        self.con.sendmail(Sender, To, msg.as_string())
        self.close()

    def close(self):
        self.con.quit()


    def Senter_to_from(self, Sender):
        From = Sender + '<' + Sender + '>'
        return From
