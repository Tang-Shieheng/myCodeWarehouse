"""
 @author : 唐仕恒
 @filename : 01_连接数据库.py
 @createtime :2020/6/26 16:41
 @IDE : PyCharm
"""
# 导入pymssql包
import pymssql

# 1. 连接数据库, 设置主机名，账户和登录密码，以及要连接的数据库
host = 'localhost'
user = 'root'
password = 'root'
database = 'BIRTHDAY'
# 使用pymssql的connect方法创建一个数据库连接
connect = pymssql.connect(host, user, password, database)
# 连接成功
if connect:
    # 声明一个游标，用来执行SQL语句
    cursor = connect.cursor()
    # 2. 编写SQL语句并执行
    sql = "select top 10 name, birthday, email from tb_birthday"
    cursor.execute(sql)
    # 3. 输出结果
    # 输出一条记录fetchone（）,输出多条记录fetchall()
    print(cursor.fetchone())
    # 4. 关闭连接
    cursor.close()
    connect.close()
# 连接失败
else:
    print('连接失败')

