"""
 @author : 唐仕恒
 @filename : 04_测试邮箱连接.py
 @createtime :2020/6/26 21:59
 @IDE : PyCharm
"""
from Email import Email

MailServer = 'smtp.163.com'
port = 465
email = '17073858552@163.com'
password = open('files/password', encoding='utf-8').read()

emailConnect = Email(MailServer, port, email, password)

sender = '17073858552@163.com'
to = '415331174@qq.com'
subject = '生日祝福'
text = '生日快乐！'
emailConnect.sendmail(sender, to, subject, text)