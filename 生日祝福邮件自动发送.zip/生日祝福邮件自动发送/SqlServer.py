"""
 @author : 唐仕恒
 @filename : SqlServer.py
 @createtime :2020/6/26 19:46
 @IDE : PyCharm
"""
import pymssql

class SqlServer():
    # 初始化方法，接收参数
    def __init__(self, host, user, password, database):
        self.host = host
        self.user = user
        self.password = password
        self.database = database

    # 创建数据库连接并生成游标
    def connect(self):
        self.dbconnect = pymssql.connect(self.host, self.user, self.password, self.database)
        # as_dict = True
        self.cursor = self.dbconnect.cursor()

    # 获取一条数据
    def get_one(self, sql):
        result = 0
        try:
            self.connect()
            self.cursor.execute(sql)
            result = self.cursor.fetchone()
            self.close()
        except Exception as E:
            print('error:', E)
        return result

    # 获取多条数据
    def get_all(self, sql):
        result = 0
        try:
            self.connect()
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            self.close()
        except Exception as E:
            print('error', E)
        return result

    # 关闭连接
    def close(self):
        self.cursor.close()
        self.dbconnect.close()