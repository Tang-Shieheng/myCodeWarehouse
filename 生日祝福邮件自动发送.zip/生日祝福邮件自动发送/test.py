"""
 @author : 唐仕恒
 @filename : test.py
 @createtime :2020/6/26 22:26
 @IDE : PyCharm
"""

result = [
    ['Apple', 'Google', 'Microsoft'],
    ['Java', 'Python', 'Ruby', 'PHP'],
    ['Adam', 'Bart', 'Lisa']
]
print(type(result))
for row in result:
    print(row, type(row))
