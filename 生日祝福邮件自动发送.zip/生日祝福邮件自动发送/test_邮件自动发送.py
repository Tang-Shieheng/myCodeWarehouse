"""
 @author : 唐仕恒
 @filename : test_邮件自动发送.py
 @createtime :2020/6/26 22:12
 @IDE : PyCharm
"""
# -*- coding: UTF-8 -*-
from SqlServer import SqlServer
from Email import Email
import datetime

def main():
    host = 'localhost'
    user = 'root'
    password = 'root'
    database = 'BIRTHDAY'
    # 连接数据库
    connect = SqlServer(host, user, password, database)
    # 查询当前日期是否有人生日
    today = datetime.date.today().strftime("%m-%d")
    sql = 'select top 10 name, email from tb_birthday ' + ' where right(birthday, 5) = \'' + today + '\''
    result = connect.get_all(sql)
    # 如果有人生日，发送生日祝福邮件
    if result:
        # 有记录，建立邮箱连接
        MailServer = 'smtp.163.com'
        port = 465
        email = '17073858552@163.com'
        password = open('files/password', encoding='utf-8').read()
        emailConnect = Email(MailServer, port, email, password)
        sender = '17073858552@163.com'
        # 多个人同一天生日时发送多份邮件
        for row in result:
            # 设置发件人和邮件主题
            subject = '生日祝福'
            # 收件人
            name = row[0]
            to = row[1]
            text = name + ',祝你生日快乐！'
            # 自动发送邮件
            emailConnect.sendmail(sender, to, subject, text)
            # 邮件发送成功提醒
            subject = '邮件发送提醒'
            to = '415331174@qq.com'
            text = name + '的生日祝福已发送成功'
            emailConnect.sendmail(sender, to, subject, text)

if __name__ == '__main__':
    main()
